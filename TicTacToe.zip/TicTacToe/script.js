07.28 12:25 pm
script.js
document.addEventListener("DOMContentLoaded", () => {
    const cells = document.querySelectorAll('[data-cell]');
    const board = document.getElementById('board');
    const restartButton = document.getElementById('restartButton');
    const winnerMessage = document.getElementById('winnerMessage');
    const WINNING_COMBINATIONS = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];
    let circleTurn;
    let isPlayerTurn;
    let aiTimeout;

    function startGame() {
        clearTimeout(aiTimeout);
        circleTurn = Math.random() < 0.5;
        isPlayerTurn = Math.random() < 0.5;
        cells.forEach(cell => {
            cell.classList.remove('x');
            cell.classList.remove('circle');
            cell.removeEventListener('click', handleClick);
            cell.addEventListener('click', handleClick, { once: true });
        });
        winnerMessage.textContent = ''; // Clear any previous winner message
        if (!isPlayerTurn) {
            aiTimeout = setTimeout(aiMove, 1000); // AI makes the first move with a delay
        }
    }

    function handleClick(e) {
        const cell = e.target;
        const currentClass = circleTurn ? 'circle' : 'x';
        placeMark(cell, currentClass);
        if (checkWin(currentClass)) {
            endGame(false);
        } else if (isDraw()) {
            endGame(true);
        } else {
            swapTurns();
            if (!isPlayerTurn) {
                aiTimeout = setTimeout(aiMove, 1000); // AI moves with a delay
            }
        }
    }

    function placeMark(cell, currentClass) {
        cell.classList.add(currentClass);
    }

    function swapTurns() {
        circleTurn = !circleTurn;
        isPlayerTurn = !isPlayerTurn;
    }

    function checkWin(currentClass) {
        return WINNING_COMBINATIONS.some(combination => {
            return combination.every(index => {
                return cells[index].classList.contains(currentClass);
            });
        });
    }

    function isDraw() {
        return [...cells].every(cell => {
            return cell.classList.contains('x') || cell.classList.contains('circle');
        });
    }

    function endGame(draw) {
        if (draw) {
            winnerMessage.textContent = "Draw!";
        } else {
            winnerMessage.textContent = `${circleTurn ? "O's" : "X's"} Wins!`;
        }
        cells.forEach(cell => cell.removeEventListener('click', handleClick)); // Disable further moves
    }

    function aiMove() {
        const availableCells = [...cells].filter(cell => {
            return !cell.classList.contains('x') && !cell.classList.contains('circle');
        });
        if (availableCells.length === 0) return;
        const randomIndex = Math.floor(Math.random() * availableCells.length);
        const cell = availableCells[randomIndex];
        const currentClass = circleTurn ? 'circle' : 'x';
        placeMark(cell, currentClass);
        if (checkWin(currentClass)) {
            endGame(false);
        } else if (isDraw()) {
            endGame(true);
        } else {
            swapTurns();
            if (!isPlayerTurn) {
                aiTimeout = setTimeout(aiMove, 1000); // AI moves with a delay
            }
        }
    }

    restartButton.addEventListener('click', startGame);
    startGame();
});
